package inputHandler;

public interface Locator {
	public TextLocation getLocation();
}
